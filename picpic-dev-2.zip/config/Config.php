<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 6:54 AM
 */

namespace config;

trait Config
{
    protected $database = [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port'=>'3306',
        'dbname' => 'mustafa',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8'
    ];

}