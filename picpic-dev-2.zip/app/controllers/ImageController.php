<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 18:44
 */

namespace app\controllers;

use app\models\Comment;
use app\models\Image;
use helpers\Cache;
use helpers\Pagination;

class ImageController extends Controller
{
    public function images()
    {
        $cache = new Cache();
        $images = $cache->get("images");
        if ($images == null) {
            $img = (new Image())->limit("0","8")->order_by_desc()->get();
            $cache->set("images", $img, 30);
            $images = $cache->get("images");
        }
        return $this->view("images/images", compact('images'));
    }

    public function pagination($id)
    {
        $page = new Pagination();
        $images = $page->pagination($id, 8, "images");
       /*$prev = -6 + ($id * 7);
       $images = (new Image())->limit($prev, 8)->get();*/
        return $this->view("images/images", compact('images'));
    }

    public function details($id)
    {
        $this->id = $id;
        $image = (new Image())->find($id);
        $comments = (new Comment())->where("image_id", $id)->get();
        return $this->view("images/details", compact("image", "comments"));
    }
}