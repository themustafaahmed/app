<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 16.10.2018 г.
 * Time: 15:47
 */

namespace app\controllers;

require "./vendor/smarty/libs/SmartyBC.class.php";

use SmartyBC;

class Controller
{
    private $smarty;
    function __construct()
    {
        $this->smarty = new SmartyBC();
    }

    protected function view($file, $var = false)
    {
        is_array($var) ? extract($var) : '';
        return include(ROOT_PATH ."/app/views/".$file.".view.php");
    }

    protected function redirect($redirect){
        return header("location:$redirect");
    }

    protected function smarty(){
        $this->smarty->setTemplateDir("./app/views");
        $this->smarty->setCompileDir("./system/smarty_c");
        return $this->smarty;
    }
}