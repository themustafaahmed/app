<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 5:06 PM
 */

namespace app\controllers;

use app\models\Comment;
use app\models\Image;
use helpers\Request;
use helpers\Session;

class CommentController extends Controller
{
    private $id;

    public function commentPost(Request $request)
    {
        $comment = $request->input("comment");
        $id = $request->input("id");

        $user = Session::get('user');
        $user_id = null;
        if (isset($user)) {
            $user_id = $user[0]['id'];
        }
        if ($comment != null) {
            $_comment = (new Comment())->insert([
                "content" => $comment,
                "user_id" => $user_id,
                "image_id" => $id,
                'created_at' => date("Y-m-d h:i:sa"),
                'updated_at' => date("Y-m-d h:i:sa"),
            ]);
            if ($_comment) {
                echo "ok";
            } else {
                echo "Err";
            }
        } else {
            echo "Empty Body";
        }
    }

    public function fechComments($id)
    {
       // $comments = (new Comment())->where("image_id",$id)->get();
        $comments =  (new Comment())
            ->select("comments.*,users.username")
            ->leftJoin("users","users.id = comments.user_id")
            ->where("image_id",$id)
            ->get();
        $data = $this->view('comments/comments',compact('comments'));
        return compact('data');
    }

    public function removeComments($id){
        $comment = (new Comment())->where("id",$id)->delete();
        if($comment){
            echo "ok";
        }else{
            echo "err";
        }
        $this->redirect("/image-details/15");
    }

    public function editCommentsGet($id){
        $comment = (new Comment())->where("id",$id)->get();
        return $this->view("comments/edit-comment",compact("comment"));
    }

    public function editCommentPost($id,$comment){
        echo $comment;
        echo $id;
        $_comment = (new Comment())->where("id",$id)->update(['content'=>$comment]);
        if($_comment){
            echo "ok";
        }else{
            echo "err";
        }
       // return $this->redirect("/");
    }


    public function joins(){
       $join =  (new Comment())
           ->select("comments.content,users.username")
           ->innerJoin("users","users.id = comments.user_id")
           ->where("image_id","15")
           ->get();
       print_r($join);
    }
}