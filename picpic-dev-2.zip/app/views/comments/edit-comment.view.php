<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 11/1/2018
 * Time: 3:39 PM
 */

?>

<div class="panel panel-default">
    <div class="panel-heading">
        <strong> <?php
            if($comment[0]['user_id'] != null)
                echo $comment['user_id'];
            else
                echo "Anonymous";
            ?>
        </strong>
        <span class="text-muted"><?php $date = $comment[0]["created_at"];$format = date("m-d-Y", strtotime($date));echo $format;?></span>


    </div>
    <form action="/comment/edit" method="post">
    <div class="panel-body">
        <textarea placeholder="What are you doing right now?" name="comment"><?php echo $comment[0]['content'] ?></textarea>
    </div><!-- /panel-body -->
    <div class="btn-group">
        <input  type="hidden" name="comment_id" value="<?php echo $comment[0]["id"]?>">
        <input type="submit" id="edit-comment"class="btn btn-outline-primary" value="Save"/>
        </form>
    </div>
</div><!-- /panel panel-default -->
