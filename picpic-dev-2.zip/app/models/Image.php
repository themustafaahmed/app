<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 1:13
 */

namespace app\models;

use database\Database;

class Image extends Database
{
    protected static $table = "images";
}