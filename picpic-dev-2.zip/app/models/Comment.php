<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 10/30/2018
 * Time: 5:13 PM
 */

namespace app\models;


use database\Database;

class Comment extends Database
{
    protected static $table = "comments";
}