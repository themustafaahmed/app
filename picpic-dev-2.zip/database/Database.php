<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 16.10.2018 г.
 * Time: 21:28
 */

namespace database;

use config\Config;
use http\Exception;

include_once "./config/Config.php";

class Database extends \PDO
{
    use Config;
    private $table;
    private $connect;
    private $find;
    private $array_execute;
    private $where;
    private $order_by;
    private $delete;
    private $limit;
    private $insert, $insert_colum, $insert_value;
    private $update;
    private $innerJoin;
    private $select;
    private $join;
    private $leftJoin;
    private $rightJoin;

    public function __construct()
    {
        $dns = $this->database['driver'] . ":host=" . $this->database['host'] . ";"
            . "port=" . $this->database['port'] . ";"
            . "dbname=" . $this->database['dbname'] . ";"
            . "charset=" . $this->database['charset'] . ";";
        $username = $this->database['username'];
        $password = $this->database['password'];
        $this->connect = new \PDO("$dns", "$username", "$password");
       /* if($this->connect){
            echo "Connected";
        }else{
            echo "Connection Failed";
        }*/
        $this->table = static::$table;
    }

    public function find($id)
    {
        $this->find = $this->connect->prepare("select * from " . $this->table . " where id=" . $id);
        $this->find->bindParam("id", $id);
        $this->find->execute();
        return $this->find->fetch(\PDO::FETCH_ASSOC);
    }

    public function get()
    {
        if ($this->select == null) {
            $this->select = " SELECT * FROM ";
        }
      //  echo "$this->select $this->innerJoin $this->join $this->where $this->order_by $this->limit";
        $this->find = $this->connect->prepare("$this->select $this->table $this->join $this->where $this->order_by $this->limit");
        $this->find->execute($this->array_execute);
        return $this->find->fetchAll();
    }

    public function where($colum_name, $colum_value)
    {
        if (!$this->where) {
            $this->where = " where " . $colum_name . "=? ";
            $this->array_execute[] = $colum_value;
        } else {
            $this->where .= " and $colum_name" . "=?";
            $this->array_execute[] = $colum_value;
        }
        return $this;
    }

    public function order_by_asc($colum = "id")
    {
        $this->order_by = " order by $colum asc ";
        return $this;
    }

    public function order_by_desc($colum = "id")
    {
        $this->order_by = " order by $colum desc ";
        return $this;
    }

    public function delete()
    {
        $this->delete = $this->connect->prepare("delete from $this->table $this->where");
        return $this->delete->execute($this->array_execute);
    }

    public function insert(array $insert)
    {
        $this->insert_colum = implode(',', array_keys($insert));
        $this->insert_value = implode(',', array_fill(0, count($insert), '?'));
        $this->insert = $this->connect->prepare("INSERT INTO " . $this->table . " ($this->insert_colum) VALUES ($this->insert_value)");
        return $this->insert->execute(array_values($insert));
    }

    public function limit($start, $finish)
    {
        $this->limit = " limit $start,$finish ";
        return $this;
    }

    public function update(array $update)
    {
        foreach ($update as $item => $value) {
            $this->update .= $item . "=" . $value . ",";
        }
        $this->update = substr($this->update, 0, -1);
        $this->update = $this->connect->prepare("update " . $this->table . " set " . $this->update . $this->where);
        return $this->update->execute($this->array_execute);
    }

    public function innerJoin($table, $on)
    {
        $this->join = " INNER JOIN $table ON $on ";
        return $this;
    }

    public function join($join, $on)
    {
        $this->join = " JOIN $join ON $on ";
        return $this;
    }

    public function select($select = "*")
    {
        $this->select = " SELECT $select FROM $this->table ";
        return $this;
    }

    public function table($name){
        $this->table = $name;
        return $this;
    }

    public function leftJoin($table, $on){
        $this->join = " LEFT JOIN $table ON $on ";
        return $this;
    }
    public function rightJoin($table, $on){
        $this->join = " RIGHT JOIN $table ON $on ";
        return $this;
    }
}