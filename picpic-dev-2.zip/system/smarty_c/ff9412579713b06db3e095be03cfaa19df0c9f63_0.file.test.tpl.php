<?php
/* Smarty version 3.1.33, created on 2018-11-01 16:30:34
  from 'D:\xampp\htdocs\app\views\test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5bdb1c1ab9eb84_19450290',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff9412579713b06db3e095be03cfaa19df0c9f63' => 
    array (
      0 => 'D:\\xampp\\htdocs\\app\\views\\test.tpl',
      1 => 1541086232,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bdb1c1ab9eb84_19450290 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['title_text']->value, ENT_QUOTES, 'UTF-8', true);?>
</title>
</head>

<body> <h1>Smarty Template </h1>
</body> <!-- this is a little comment that will be seen in the HTML source -->
</html><?php }
}
