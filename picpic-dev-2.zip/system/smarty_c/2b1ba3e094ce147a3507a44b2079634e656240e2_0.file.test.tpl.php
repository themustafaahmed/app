<?php
/* Smarty version 3.1.33, created on 2018-11-01 16:33:50
  from 'D:\xampp\htdocs\app\views\test\test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5bdb1cde878924_84171836',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2b1ba3e094ce147a3507a44b2079634e656240e2' => 
    array (
      0 => 'D:\\xampp\\htdocs\\app\\views\\test\\test.tpl',
      1 => 1541086429,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bdb1cde878924_84171836 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Test Smarty</title>
</head>

<body> <h1>Smarty Template </h1>
</body> <!-- this is a little comment that will be seen in the HTML source -->
</html><?php }
}
