<?php
/* Smarty version 3.1.33, created on 2018-11-02 13:46:15
  from 'D:\xampp\htdocs\app\views\home\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5bdc4717724070_16746679',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '605ca29dc5a9953f15c2b10b625c4badc7d4e0b0' => 
    array (
      0 => 'D:\\xampp\\htdocs\\app\\views\\home\\home.tpl',
      1 => 1541162600,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bdc4717724070_16746679 (Smarty_Internal_Template $_smarty_tpl) {
include('./app/views/layouts/header.view.php');
?>

<div id="container">
    <div id="tj_container" class="tj_container">
        <div class="tj_wrapper">
            <ul class="tj_gallery" style="margin:0; padding:0">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['images']->value, 'image');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['image']->value) {
?>
                    <li><a href="/image-details/<?php echo $_smarty_tpl->tpl_vars['image']->value['id'];?>
"><img src="./uploads/<?php echo $_smarty_tpl->tpl_vars['image']->value['path'];?>
" alt=""></a></li>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </ul>
        </div>
    </div>
    <!-- END Portfolio -->
</div>
<!-- END container -->

<?php 
    include('./app/views/layouts/footer.view.php');
}
}
