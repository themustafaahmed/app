<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 11/1/2018
 * Time: 5:51 PM
 */

namespace helpers;

class Cache
{
    private $memcached;

    function __construct()
    {
        $this->memcached = new \Memcache();
        $this->memcached->connect('localhost', 11211);
    }

    public function set($key,$values,$expire = null,$compressed_type=MEMCACHE_COMPRESSED){
        $this->memcached->set($key,$values,$compressed_type,$expire);
    }

    public function get($key){
       return $this->memcached->get($key);
    }

}