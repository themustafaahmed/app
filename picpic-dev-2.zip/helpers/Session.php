<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 21:10
 */

namespace helpers;


class Session
{
    public static function set($session_name,$session_values){
        $_SESSION[$session_name] = $session_values;
    }

    public static function start(){
        session_start();
    }

    public static function get($name){
        if(isset($_SESSION[$name])) {
            return $_SESSION[$name];
        }else{
            return null;
        }
    }

    public static function flush($name){
        unset($_SESSION[$name]);
    }
}