<?php
/**
 * Created by PhpStorm.
 * User: eurocoders
 * Date: 11/2/2018
 * Time: 12:40 PM
 */

namespace helpers;


use database\Database;

class Pagination extends Database
{
    static $table;
    public function pagination($id,$show,$table)
    {
        self::$table = $table;
        if ($id == 0) {
            $id =1;
        }
       // $q = $show;
        $w = $show - ($show*2 -1);
        $prev = $w + ($id * $show);
        $prev -= 1;
        return $images = $this->table(self::$table)->limit($prev, $show)->order_by_desc()->get();
    }
}