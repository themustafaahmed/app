<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 30.10.2018 г.
 * Time: 15:36
 */

namespace helpers;
use security\Csrf;

class Request
{
    private $req;
    private $csrf;
    function __construct()
    {
        $this->req = $_REQUEST;
        $this->csrf = Session::get('_csrf');
        if(empty($this->req['_token']))
            return "Csrf Token not found";
        if(isset($this->csrf) && $this->csrf['token'] === $this->req['_token'])
            return $this->req;
        else
            return "CSRF Token Failed";
    }

    public function input($name){
//        if(empty($this->req['_token']))
//            return print "Csrf Token not found";
       // if(isset($this->csrf) && $this->csrf['token'] === $this->req['_token'])
            return $this->req[$name];
        //else
         //   return "CSRF Token Failed";
    }
}