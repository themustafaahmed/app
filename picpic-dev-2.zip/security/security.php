<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 4.11.2018 г.
 * Time: 19:20
 */

    if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
        header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
        die( header( 'location: /error.php' ) );
    }
?>