<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 30.10.2018 г.
 * Time: 15:59
 */
namespace security;

/* Cross-site request forgery */
class Csrf
{
    protected static $timeout = 900;

    public static function boot()
    {
        if (empty(session_id())) {
            throw new \Exception('Session not started');
        }
    }

    public static function getToken()
    {
        static::boot();
        $token = base64_encode(openssl_random_pseudo_bytes(32));
        $_SESSION['_csrf']['time'] = time();
        $_SESSION['_csrf']['ip'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['_csrf']['token'] = $token;
        return print_r($token);
    }

    /**
     * Sets the timeout value
     *
     * @param integer $timeout
     * @return void
     */
    public static function setTimeout($timeout)
    {
        static::$timeout = $timeout;
    }
    /**
     * Tests when it expires
     *
     * @return boolean
     */
    protected static function checkTimeout()
    {
        if (isset($_SESSION['_csrf']['time'])) {
            return ($_SERVER['REQUEST_TIME'] - $_SESSION['_csrf']['time']) < static::$timeout;
        }
        return false;
    }
    /**
     * CSRF info clear
     *
     * @return void
     */
    public static function flush()
    {
        unset($_SESSION['_csrf']);
    }
}