<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 25.10.2018 г.
 * Time: 18:06
 */

namespace helpers;


class Pagination
{

}