<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 19:18
 */

include ('./app/views/admin/layouts/header.view.php');
?>
<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 19:18
 */

include ('./app/views/admin/layouts/footer.view.php');
?>


