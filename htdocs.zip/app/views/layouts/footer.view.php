<div id="footer">
    <!-- First Column -->
<!--    <div class="one-fourth">-->
<!--        <h3>Useful Links</h3>-->
<!--        <ul class="footer_links">-->
<!--            <li><a href="#">Lorem Ipsum</a></li>-->
<!--            <li><a href="#">Ellem Ciet</a></li>-->
<!--            <li><a href="#">Currivitas</a></li>-->
<!--            <li><a href="#">Salim Aritu</a></li>-->
<!--        </ul>-->
<!--    </div>-->
    <!-- Second Column -->
<!--    <div class="one-fourth">-->
<!--        <h3>Terms</h3>-->
<!--        <ul class="footer_links">-->
<!--            <li><a href="#">Lorem Ipsum</a></li>-->
<!--            <li><a href="#">Ellem Ciet</a></li>-->
<!--            <li><a href="#">Currivitas</a></li>-->
<!--            <li><a href="#">Salim Aritu</a></li>-->
<!--        </ul>-->
<!--    </div>-->
    <!-- Third Column -->
    <!--<div class="one-fourth">
        <h3>Information</h3>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
        <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
            Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
    </div>-->
    <!-- Fourth Column -->
    <div class="one-fourth last">
        <h3>© 2018</h3>
        <img src="img/icon_fb.png" alt=""> <img src="img/icon_twitter.png" alt=""> <img src="img/icon_in.png" alt=""> </div>
    <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>