<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 21.10.2018 г.
 * Time: 17:09
 */

trait Config
{
    protected $database = [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port'=>'3306',
        'dbname' => 'pictagram',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8'
    ];
}