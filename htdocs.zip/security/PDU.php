<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 25.10.2018 г.
 * Time: 18:42
 */

namespace security;


class PDU
{
    public function check()
    {
        echo realpath(__FILE__) ;
        echo realpath($_SERVER['SCRIPT_FILENAME']);
        if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {
            /* Up to you which header to send, some prefer 404 even if
               the files does exist for security */
            echo "PDU";
            header('HTTP/1.0 403 Forbidden', TRUE, 403);
            /* choose the appropriate page to redirect users */
            die(header('location: /error.php'));

        }
    }
}