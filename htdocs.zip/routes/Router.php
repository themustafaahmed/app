<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 17.10.2018 г.
 * Time: 17:53
 */

namespace routes;

class Router
{
    protected $actualPath;
    protected $actualMethod;
    protected $routes = [];
    protected $notFound;
    protected static $patterns = [
        ':number' => '(\d+)',
        ':id' => '(\d+)',
        ':string' => '([\qw-_]+)',
        ':slug' => '([\w\-_]+)',
        ':any' => '([^/]+)',
        ':all' => '(.*)',
    ];
    /*$currentPath, $currentMethod*/
    public function __construct()
    {
        $this->actualPath = $_SERVER['REQUEST_URI'];/*$currentPath;*/
        $this->actualMethod = $_SERVER['REQUEST_METHOD'];/*$currentMethod;*/
        $this->notFound = function(){
            http_response_code(404);
            echo '404 Not Found';
        };
    }

    public function get($path, $callback)
    {
        $this->routes[] = ['GET', $path, $callback];
    }

    public function post($path, $callback)
    {
        $this->routes[] = ['POST', $path, $callback];
    }

    public function run()
    {
        foreach ($this->routes as $route) {
            list($method, $path, $callback) = $route;
            $checkMethod = $this->actualMethod == $method;
            $checkPath = preg_match("~^{$path}$~ixs", $this->actualPath, $params);
            if ($checkMethod && $checkPath) {
                array_shift($params);
                return call_user_func_array($callback, $params);
            }
        }
        return call_user_func($this->notFound);
    }
}