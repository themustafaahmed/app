
/**Create comment*/
$(function () {
    $("#submit-comment").on("click", function () {
        var comment = $("[name=comment]").val();
        var id = $("[name=id]").val();
        $.ajax({
            url: "/comment",
            data: {comment: comment, id: id},
            type: "POST",
            success: function (data) {
                if(data.error != '')
                {
                    $('#comment_form').find("textarea").val('');
                    loadComments();
                }
                console.log("comment saved");
            },
            error: function (xhr, textStatus, exceptionThrown) {
                alert(xhr.responseText);
            }
        });
    });
    loadComments();
});

/**Fech comments and response*/
function loadComments() {
    var id = $("[name=id]").val();
    $.ajax({
        url: "/fech-comments/"+id,
        method: "GET",
        success: function (data) {
            $("#comments").html(data);
        }
    })
}

/**Remove comment */
$(function () {
    $(".remove-comment").on("click", function () {
        var id = $("[name=comment_id]");
        var item = $(this);
        alert(id);
        alert('test');
        $.ajax({
            type: "POST",
            url: "/comment/remove",
            data:id,
            success: function () {
                console.log("comment removed");
                item.parent().parent().remove();
            }
        });
    });
});

/**Update comment */
$(function () {
    $("#update-comment").on("click", function () {
        var id = $("[name=comment_id]");
        var new_comment = $("[name=comment]");
        var item = $(this);
        alert('test');
        $.ajax({
            type: "POST",
            url: "/comment/update",
            data:id,
            success: function () {
                console.log("comment removed");
                item.parent().parent().remove();
            }
        });
    });
});

