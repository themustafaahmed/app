<div id="footer">
    <!-- Fourth Column -->
    <div class="one-fourth last">
        <h5 style="display: inline-block">© 2018</h5>
        <img src="img/icon_fb.png" alt="">
        <img src="img/icon_twitter.png" alt="">
        <img src="img/icon_in.png" alt="">
    </div>
    <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>